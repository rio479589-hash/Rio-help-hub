Go to:
\Documents\TMInterface

You will also find a scripts folder there, which has your input files. You can store some of those files to your desktop to saved different ideas.